
const TELNET_TIMEOUT = 60000

let Telnet = require('telnet-client');

module.exports = {

}