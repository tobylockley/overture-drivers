# Rane Halogen Audio Control Software

##Overview

Interacts with a HAL

##Setup
Host: IP address of the HAL/Halogen system
Port: Default 4996
Levels: Level controls (0-100%), e.g. volume/eq.
Selectors: Radio button inputs, e.g. source select.
Toggles: On/off inputs, e.g. mute.

##Commands

##Variables

###Power

##Release Notes
