const TICK_PERIOD = 15000
const POLL_PERIOD = 5000
const TCP_TIMEOUT = 30000
const TCP_RECONNECT_DELAY = 5000
const CMD_DEFER_TIME = 5000


var host
exports.init = _host => {
  host = _host
}


exports.createDevice = base => {
  const logger = base.logger || host.logger
  var config
  var tcpClient
  let Telnet = require('telnet-client');

  var frameParser = host.createFrameParser()
  frameParser.setSeparator('\r')
  frameParser.on('data', data => onFrame(data))


  const setup = _config => {
    config = _config
    base.setTickPeriod(TICK_PERIOD);
    base.setPoll({
      action: 'doPolling',
      period: POLL_PERIOD,
      startImmediately: true
    });

    base.createVariable({
      name: `RunTest`,
      type: 'enum',
      enums: [
        '1',
        '2',
        '3'
      ],
      perform: {
        action: 'doTesting',
        params: { Name: 'RunTest', Data: '$string' }
      }
    })
  }


  const start = () => {
    tcp = host.createTCPClient();
    telnet = new Telnet();
    tcp_type = (typeof tcp).toString();
    telnet_type = (typeof telnet).toString();

    cTcp = tcp.constructor.name.toString();
    cTelnet = telnet.constructor.name.toString();

    // initTcpClient();
  }


  const stop = () => {
    base.getVar('Status').string = 'Disconnected';
    if (tcpClient) {
      tcpClient.end();
      tcpClient = null;
    }
  }


  const tick = () => {
    // logger.info('TICK!')
    // !tcpClient && initTcpClient();
  }


  const initTcpClient = () => {
    if (!tcpClient) {
      tcpClient = host.createTCPClient();
      tcpClient.setOptions({
        autoReconnectionAttemptDelay: TCP_RECONNECT_DELAY,
        receiveTimeout: TCP_TIMEOUT
      });
      tcpClient.connect(config.port, config.host);

      tcpClient.on('connect', () => {
        logger.info(`TCPClient connected`);
        base.getVar('Status').string = 'Connected';
        base.startPolling();
      })

      tcpClient.on('data', data => {
        frameParser.push(data.toString());
        // logger.silly(`TCPClient data: ${data}`)
      })

      tcpClient.on('close', () => {
        logger.info(`TCPClient closed`);
        base.getVar('Status').string = 'Disconnected';
      })

      tcpClient.on('error', err => {
        logger.error(`TCPClient: ${err}`);
        stop();
      })
    }
  }


  const send = data => {
    logger.silly(`TCPClient send: ${data}`)
    return tcpClient && tcpClient.write(data)
  }


  const sendDefer = data => {
    base.commandDefer(CMD_DEFER_TIME);
    if (!send(data)) base.commandError(`Data not sent`);
  }


  const onFrame = data => {
    logger.silly(`onFrame data: ${data}`)
    let match = data.match(/.+/)
    if (match) {
      base.commandDone('command is done')  // Call this when a command response is recognised
      base.getVar('Test').string = data.replace(/\s/, '')
    }
    else {
      base.commandError('command errored')  // Call this when something goes wrong
    }
  }


  const doTesting = params => {
    logger.debug(`Testing: ${params.Data}`);
    let v = base.getVar('Source')
    base.getVar('Source').enums = ['foo', 'bar']
    logger.silly()
  }


  const doPolling = () => {
    logger.debug(`Polling, tcpClient.isConnected = ${tcpClient.isConnected()}`);
    sendDefer('getversion\r');
  }


  const setVolume = params => {
    logger.debug(`Setting Volume: ${params.Level}`);
    base.getVar('Volume').value = params.Level;
  }


  const setSource = params => {
    logger.debug(`Setting Source: ${params.Status}`);
    base.getVar('Source').string = params.Status;
  }


  const setMessage = params => {
    logger.debug(`Setting Message: ${params.Data}`);
    base.getVar('Message').string = params.Data;
  }


  return {
    setup, start, stop, tick,
    doTesting, doPolling, setVolume, setSource, setMessage
  }
}