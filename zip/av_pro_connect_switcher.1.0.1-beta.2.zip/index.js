'use strict';

const CMD_DEFER_TIME = 1000;        // Timeout when using commandDefer
const TICK_PERIOD = 5000;           // In-built tick interval
const POLL_PERIOD = 5000;           // Continuous polling function interval
const TCP_TIMEOUT = 30000;          // Will timeout after this length of inactivity
const TCP_RECONNECT_DELAY = 3000;   // How long to wait before attempting to reconnect


let host;
exports.init = _host => {
  host = _host;
};


exports.createDevice = base => {
  const logger = base.logger || host.logger;
  let config;
  let tcpClient;

  let frameParser = host.createFrameParser();
  frameParser.setSeparator('\r\n');
  frameParser.on('data', data => onFrame(data));


  // ------------------------------ SETUP FUNCTIONS ------------------------------

  function isConnected() { return base.getVar('Status').string === 'Connected'; }

  function setup(_config) {
    config = _config;
    base.setTickPeriod(TICK_PERIOD);
    base.setPoll('Get All Outputs', 10000);
    base.setPoll({ action: 'getChannel', period: POLL_PERIOD, enablePollFn: isConnected, startImmediately: true });
    logger.info(`Inputs: ${config.model.num_outputs}, Output: ${config.model.num_outputs}`)

    for (let i = 1; i <= config.model.num_outputs; i++) {
      let var_name = `Sources_Output${i}`;

      let inputs = [];
      for (let j = 1; j <= config.model.num_outputs; j++) {
        const name = config.model.input_names[`input${j}`];
        if (name != '') inputs.push(name);
        else inputs.push(`Input${j}`);
      }
      // base.createVariable({
      //   name: var_name,
      //   type: 'enum',
      //   enums 
      //   perform: {
      //     action: 'Set Output',
      //     params: {
      //       Channel: i,
      //       Name: '$value',
      //       VariableName: var_name
      //     }
      //   }
      // });
    }
  }

  function start() {
    if (config.simulation) base.getVar('Status').string = 'Connected';
    else initTcpClient();
  }

  function stop() {
    base.getVar('Status').string = 'Disconnected';
    tcpClient && tcpClient.end();
    tcpClient = null;
  }

  function tick() {
    if (!config.simulation && !tcpClient) initTcpClient();
  }

  function initTcpClient() {
    if (tcpClient) return;  // Return if tcpClient already exists

    tcpClient = host.createTCPClient();
    tcpClient.setOptions({
      receiveTimeout: TCP_TIMEOUT,
      autoReconnectionAttemptDelay: TCP_RECONNECT_DELAY
    });
    tcpClient.connect(config.port, config.host);

    tcpClient.on('connect', () => {
      logger.silly('TCPClient connected');
      base.getVar('Status').string = 'Connected';
      base.startPolling();
    });

    tcpClient.on('data', data => {
      frameParser.push( data.toString() );
    });

    tcpClient.on('close', () => {
      logger.silly('TCPClient closed');
      base.getVar('Status').string = 'Disconnected';  // Triggered on timeout, this allows auto reconnect
    });

    tcpClient.on('error', err => {
      logger.error(`TCPClient: ${err}`);
      stop();  // Throw out the tcpClient and get a fresh connection
    });
  }


  // ------------------------------ SEND/RECEIVE HANDLERS ------------------------------

  function send(data) {
    logger.silly(`TCPClient send: ${data}`);
    return tcpClient && tcpClient.write(data);
  }

  function sendDefer(data) {
    if (send(data)) base.commandDefer(CMD_DEFER_TIME);
    else base.commandError('Data not sent');
  }

  function onFrame(data) {
    let match;  // Used for regex matching below
    logger.silly(`onFrame ${data}`);

    match = data.match(/OUT(\d).*IN(\d)/i);
    if (match) {
      base.getVar(`Output${match[1]}`).value = parseInt(match[2]);
      base.commandDone();
    }
  }


  // ------------------------------ GET FUNCTIONS ------------------------------

  function getAllOutputs() {
    sendDefer('GET OUT0 VS\r\n');  // Get all outputs
  }

  function getOutput(params) {
    sendDefer(`GET OUT${params.Channel} VS\r\n`);
  }


  // ------------------------------ SET FUNCTIONS ------------------------------

  function selectSource(params) {
    if (config.simulation) {
      base.getVar(params.VariableName).string = params.Name;
      return;
    }

    logger.debug(`Connecting Input${params.Name} to Output${params.Channel}`);
    sendDefer(`SET OUT${params.Output} VS IN${params.Input}\r\n`);
  }


  // ------------------------------ EXPORTED FUNCTIONS ------------------------------

  return {
    setup, start, stop, tick,
    getAllOutputs, getOutput, selectSource
  };
};


