'use strict';

const TICK_PERIOD = 5000;           // In-built tick interval
const POLL_PERIOD = 5000;           // Continuous polling function interval
const TCP_TIMEOUT = 30000;          // Will timeout after this length of inactivity
const TCP_RECONNECT_DELAY = 3000;   // How long to wait before attempting to reconnect

let host;
exports.init = _host => {
  host = _host;
};

exports.createDevice = base => {
  const logger = base.logger || host.logger;
  let config;
  let request = host.request;


  // ------------------------------ SETUP FUNCTIONS ------------------------------

  function setup(_config) {
    config = _config;
    base.setTickPeriod(TICK_PERIOD);
  }

  function start() {
  }

  function tick() {
    // get status, set connected state
  }

  function stop() {
    base.getVar('Status').string = 'Disconnected';
  }


  // ------------------------------ SEND/RECEIVE HANDLERS ------------------------------

  function onFrame(data) {
    let match;  // Used for regex matching below
    const pendingCommand = base.getPendingCommand();

    logger.silly(`onFrame: ${data}`);
    pendingCommand && logger.debug(`pendingCommand: ${pendingCommand.action}`);

    // Use arrays to match pending command action to expected response
    const setFns = [ 'setPower', 'selectSource', 'setAudioLevel', 'setAudioMute', 'setChannel', 'shiftChannel' ];

    if ( pendingCommand && setFns.includes(pendingCommand.action) ) {
      // Parse response after issueing a SET function

      match = data.match(/POWR0{16}/);
      if (match) {
        base.getVar('Power').string = pendingCommand.params.Status;
        base.commandDone();
      }

      match = data.match(/INPT0{16}/);
      if (match) {
        base.getVar('Sources').string = pendingCommand.params.Name;
        base.commandDone();
        if (pendingCommand.params.Name === 'DTV') getChannel();  // Get channel when set to DTV mode
      }

      match = data.match(/VOLU0{16}/);
      if (match) {
        base.getVar('AudioLevel').value = parseInt(pendingCommand.params.Level);
        base.commandDone();
      }

      match = data.match(/AMUT0{16}/);
      if (match) {
        base.getVar('AudioMute').string = pendingCommand.params.Status;
        base.commandDone();
      }

      match = data.match(/CHNN0{16}/);
      if (match) {
        base.getVar('Channel').value = parseInt(pendingCommand.params.Name);
        base.commandDone();
      }

      match = data.match(/IRCC0{16}/);
      if (match) {
        base.getVar('ChannelShift').value = 0;  // Reset to 'idle'
        base.commandDone();
      }

    }
  }


  // ------------------------------ GET FUNCTIONS ------------------------------

  function getStatus() {
    request(`http://${config.host}/status.xml`)
      .then( function (response, body) {
        if (response.statusCode == 200) {
          //
          logger.info(body)
        }
      })
      .catch( function(err) {
        // process errors here
        logger.error(err)
      })
  }


  // ------------------------------ SET FUNCTIONS ------------------------------
  function setValue(params) {
    if (params.Status == 'Off') sendDefer('*SCPOWR0000000000000000\n');
    else if (params.Status == 'On') sendDefer('*SCPOWR0000000000000001\n');
  }


  // ------------------------------ EXPORTED FUNCTIONS ------------------------------
  return {
    setup, start, stop, tick,
    getStatus,
    setValue
  };
};