'use strict'

const CMD_DEFER_TIME = 3000        // Timeout when using commandDefer
const TICK_PERIOD = 5000           // In-built tick interval
const POLL_PERIOD = 5000           // Continuous polling function interval
const TCP_TIMEOUT = 30000          // Will timeout after this length of inactivity
const TCP_RECONNECT_DELAY = 3000   // How long to wait before attempting to reconnect

let host
exports.init = _host => {
  host = _host
}

exports.createDevice = base => {
  const logger = base.logger || host.logger
  let config
  let sshClient

  let frameParser = host.createFrameParser()
  frameParser.setSeparator('\n')
  frameParser.on('data', data => onFrame(data))


  // ------------------------------ SETUP FUNCTIONS ------------------------------

  function isConnected() { return base.getVar('Status').string === 'Connected' }

  function setup(_config) {
    config = _config
    base.setTickPeriod(TICK_PERIOD)

    // Register polling functions
    base.setPoll({ action: 'getInfo', period: POLL_PERIOD, enablePollFn: isConnected, startImmediately: true })
  }

  function start() {
    initSshClient()
  }

  function stop() {
    base.getVar('Status').string = 'Disconnected'
    sshClient && sshClient.end()
    sshClient = null
    base.stopPolling()
    base.clearPendingCommands()
  }

  function tick() {
    if (!sshClient) initSshClient()
  }

  function initSshClient() {
    if (sshClient) return  // Return if sshClient already exists

    sshClient = new require('ssh2').Client()
    // sshClient.setOptions({
    //   receiveTimeout: TCP_TIMEOUT,
    //   autoReconnectionAttemptDelay: TCP_RECONNECT_DELAY
    // })

    sshClient.on('ready', () => {
      logger.silly('sshClient connected')
      base.getVar('Status').string = 'Connected'
      base.startPolling()

      // sshClient.shell( (err, stream) => {

      // })
    })

    sshClient.on('continue', () => {
      logger.debug('sshClient continue')
    })

    sshClient.on('data', data => {
      logger.debug('sshClient data', data)
      // frameParser.push(data.toString())
    })

    sshClient.on('end', () => {
      logger.debug('sshClient end')
    })

    sshClient.on('close', () => {
      logger.debug('sshClient close')
    })

    sshClient.on('error', err => {
      logger.error(`sshClient: ${err.message}`)
      stop()  // Throw out the sshClient and get a fresh connection
    })

    sshClient.connect({
      host: config.host,
      port: config.port,
      username: 'zoom',
      password: config.password
    })
  }


  // ------------------------------ SEND/RECEIVE HANDLERS ------------------------------

  function send(data) {
    logger.silly(`sshClient send: ${data}`)
    return sshClient && sshClient.exec(data, (err, stream) => {
      if (err) logger.error('ssh exec error:', err.message)
      stream.on('close', function(code, signal) {
        console.log('Stream :: close :: code: ' + code + ', signal: ' + signal);
        sshClient.end()
        base.commandDone()
      }).on('data', function(data) {
        console.log('STDOUT: ' + data);
      }).stderr.on('data', function(data) {
        console.log('STDERR: ' + data);
      })
    })
  }

  function sendDefer(data) {
    base.commandDefer(CMD_DEFER_TIME)
    if (!send(data)) base.commandError('Data not sent')
  }

  function onFrame(data) {
    let pendingCommand = base.getPendingCommand()
    logger.debug(`onFrame (pending = ${pendingCommand && pendingCommand.action}): ${data}`)
    let match = data.match(/POWR(\d+)/)
    if (match && pendingCommand) {
      if (match && pendingCommand.action == 'getPower') {
        base.getVar('Power').value = parseInt(match[1])  // 0 = off, 1 = on
        base.commandDone()
      }
      else if (match && pendingCommand.action == 'setPower') {
        base.getVar('Power').string = pendingCommand.params.Status
        base.commandDone()
      }
    }
    else if (match && !pendingCommand) {
      logger.warn(`Received data but no pending command: ${data}`)
    }
    else {
      logger.warn(`onFrame data not processed: ${data}`)
    }
  }


  // ------------------------------ GET FUNCTIONS ------------------------------

  function getInfo() {
    sendDefer('zCommand Call Info')
  }


  // ------------------------------ SET FUNCTIONS ------------------------------
  function setPower(params) {
    if (params.Status == 'Off') sendDefer('*SCPOWR0000000000000000\n')
    else if (params.Status == 'On') sendDefer('*SCPOWR0000000000000001\n')
  }


  // ------------------------------ EXPORTED FUNCTIONS ------------------------------
  return {
    setup, start, stop, tick,
    getInfo,
    setPower
  }
}