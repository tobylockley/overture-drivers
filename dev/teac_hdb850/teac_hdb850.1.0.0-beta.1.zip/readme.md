# Sony Bravia

## Overview

Driver for a Sony Bravia device over a TCP connection.
  
## Setup

 - "Host": The IP address or host name of the device.(Default 192.168.3.20)
 - "Port": The port of TCP communication. (Default 20060)

## Variables

### Status

[enum] The current connection status of the device.
 - "Disconnected" : The device is not connected.
 - "Connected" : The device is connected, and able to receive commands.

### IR Commands

[enum] List of all available IR commands (see ir_codes.js)

## Commands

### Send Command
Send IR command corresponding to param.Name

## Revisions

### 0.0.1

- initial version

