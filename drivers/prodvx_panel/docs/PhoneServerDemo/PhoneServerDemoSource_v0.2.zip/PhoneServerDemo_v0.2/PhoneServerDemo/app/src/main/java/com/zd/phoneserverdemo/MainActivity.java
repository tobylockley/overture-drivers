package com.zd.phoneserverdemo;

import android.app.Activity;
import android.app.Service;
import android.content.Intent;
import android.os.Bundle;
import android.os.IBinder;
import android.util.Log;

import org.nanohttpd.protocols.http.IHTTPSession;
import org.nanohttpd.protocols.http.NanoHTTPD;
import org.nanohttpd.protocols.http.content.CookieHandler;
import org.nanohttpd.protocols.http.request.Method;
import org.nanohttpd.protocols.http.response.Response;
import org.nanohttpd.protocols.http.response.Status;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

public class MainActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        startService(new Intent(this, HttpService.class));
    }

    public static class HttpService extends Service {

        private HttpServer mHttpServer;

        @Override
        public IBinder onBind(Intent intent) {
            return null;
        }

        @Override
        public void onCreate() {
            mHttpServer = new HttpServer(8080);
            try {
                mHttpServer.start();
                Log.d("HttpService", "start server");
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        @Override
        public void onDestroy() {
            if (mHttpServer != null) {
                mHttpServer.stop();
            }
        }
    }


    static class HttpServer extends NanoHTTPD {

        private static final String TAG = "HttpServer";
        private LedController mLedController;

        private void LOG(String msg) {
            Log.d(TAG, "=====" + msg);
        }

        public HttpServer(int port) {
            super(port);
            mLedController = new LedController();
        }

        @Override
        protected Response serve(IHTTPSession session) {
            try {
                LOG("Method == " + session.getMethod());

                Map<String, String> head = session.getHeaders();
                Set<Map.Entry<String,String>> h = head.entrySet();
                for(Map.Entry<String, String> entry: h){
                    LOG("Header == key == " + entry.getKey() + ", value == " + entry.getValue());
                }

                LOG("ParametersString == " + session.getQueryParameterString());
                LOG("RemoteHostName == " + session.getRemoteHostName());
                LOG("RemoteIpAddress == " + session.getRemoteIpAddress());
                LOG("Uri == " + session.getUri());

                Map<String,String> p = session.getParms();
                handleLed(p.get("led"));

                Set<Map.Entry<String,String>> pp = p.entrySet();
                for(Map.Entry<String,String> entry : pp){
                    LOG("Params == key == " + entry.getKey() + ",value == " + entry.getValue());
                }

            } catch (Exception e) {
                e.printStackTrace();
            }

            Response response = Response.newFixedLengthResponse("{\"access_token\":\"test\"}");
            response.addHeader("Access-Control-Allow-Origin", "*");
            return response;
        }

        private void handleLed(String led){
            if(led != null && !led.equals("")){
                if(led.equals("ff0000")){
                    if(mLedController.catBrightness(LedController.LED_RED) == 0){
                        mLedController.turnOn(LedController.LED_RED);
                    }
                } else if(led.equals("00ff00")){
                    if(mLedController.catBrightness(LedController.LED_GREEN) == 0){
                        mLedController.turnOn(LedController.LED_GREEN);
                    }
                } else if(led.equals("ffff00")){
                    mLedController.turnOn(LedController.LED_RED);
                    mLedController.turnOn(LedController.LED_GREEN);
                } else if(led.equals("000000")){
                    mLedController.turnOff(LedController.LED_RED);
                    mLedController.turnOff(LedController.LED_GREEN);
                }
            }
        }
    }
}
