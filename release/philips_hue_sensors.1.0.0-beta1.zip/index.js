'use strict';

const hueTimeout = 10000

let host
exports.init = _host => {
  host = _host
}

exports.createDevice = base => {
  const logger = base.logger || host.logger
  let config
  let huejay = require('huejay')
  let hueClient

  const setup = _config => {
    config = _config

    config.sensors.forEach(sensor => {
      let varname = `${sensor.name}_${sensor.identifier}`
      if (sensor.type === 'Motion Sensor') {
        base.createEnumVariable(varname, ['Off', 'On'])
        base.setPoll({
          action: getMotionSensor,
          period: 5000,
          params: { Id: sensor.identifier, VarName: varname },
          enablePollFn: () => { base.getVar('Status').string === 'Connected'; }
        });
      }
      else if (sensor.type === 'Dimmer Switch') {
        base.createVariable({
          name: varname,
          type: 'integer',
          min: 1,
          max: 4
        })
        base.setPoll({
          action: getDimmerSwitch,
          period: 5000,
          params: { Id: sensor.identifier, VarName: varname },
          enablePollFn: () => { base.getVar('Status').string === 'Connected'; }
        });
      }
    });

    base.setPoll('checkConnection', 5000);
  }

  const start = () => {
    hueClient = new huejay.Client({
      host: config.host,
      username: config.username,
      timeout: hueTimeout
    });
    base.startPolling()
  }

  const stop = () => {
    disconnect()
  }

  const checkConnection = () => {
    hueClient.bridge.ping()
    .then(() => {
      let status = base.getVar('Status').string
      if (status === 'Disconnected') status = 'Connected';
    })
    .catch(error => {
      logger.error(`checkConnection: ${error}`);
      base.getVar('Status').string = 'Disconnected'
    });
  }

  const getDimmerSwitch = (params) => {
    base.commandDefer(hueTimeout + 1000)
    client.sensors.getById(params.Id)
    .then(sensor => {
      /*
        Button	Action	          Dimmer Button
        1000	  INITIAL_PRESS	    Button 1 (ON)
        1001	  HOLD
        1002	  SHORT_RELEASED
        1003	  LONG_RELEASED
        2000	  INITIAL_PRESS	    Button 2 (DIM UP)
        2001	  HOLD
        2002	  SHORT_RELEASED
        2003	  LONG_RELEASED
        3000	  INITIAL_PRESS	    Button 3 (DIM DOWN)
        3001	  HOLD
        3002	  SHORT_RELEASED
        3003	  LONG_RELEASED
        4000	  INITIAL_PRESS	    Button 4 (OFF)
        4001	  HOLD
        4002	  SHORT_RELEASED
        4003	  LONG_RELEASED
      */

      let state = base.getVar(params.VarName).value
      switch(sensor.state.buttonevent) {
        case 1000:
          state = 1
          break;
        case 2000:
          state = 2
          break;
        case 3000:
          state = 3
          break;
        case 4000:
          state = 4
          break;
        default:
          logger.debug(`getDimmerSwitch: buttonstate [${sensor.state.buttonevent}]`)
      }
      base.commandDone()
    })
    .catch(error => {
      logger.error(`getDimmerSwitch: Could not find sensor [${params.Id}]`);
      base.commandError()
      throw error;
    });
  }

  const getMotionSensor = (params) => {
    base.commandDefer(hueTimeout + 1000)
    client.sensors.getById(params.Id)
    .then(sensor => {
      base.getVar(params.VarName).string = sensor.state.presence ? 'On' : 'Off'
      base.commandDone()
    })
    .catch(error => {
      logger.error(`getMotionSensor: Could not find sensor [${params.Id}]`);
      base.commandError()
      throw error;
    });
  }

  const disconnect = () => {
    base.getVar('Status').string = 'Disconnected'
  }

  return {
    setup, start, stop,
    checkConnection, getDimmerSwitch, getMotionSensor
  }
}
