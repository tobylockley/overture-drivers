let host
exports.init = _host => {
  host = _host
}

exports.createDevice = base => {
  const logger = base.logger || host.logger
  let config
  let tcpClient

  const setup = _config => {
    config = _config
     base.setPoll('Get Power', 5000)
    // base.setPoll('Get Source', 5000)
    // base.setPoll('Get Audio Level', 5000)
  }

  const start = () => {
    initTcpClient()
    tcpClient.connect(config.port, config.host)
    base.startPolling()
  }

  const stop = () => {
    disconnect()
  }

  var Control_command = {
    UP: "1,37000,1,1,132,64,16,16,16,49,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,49,16,16,16,16,16,16,16,16,16,16,16,16,16,49,16,49,16,16,16,49,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,49,16,16,16,49,16,16,16,16,16,16,16,16,16,49,16,49,16,16,16,49,16,16,16,49,16,49,16,16,16,16,16,2704",
    DOWN: "1,37000,1,1,132,64,16,16,16,49,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,49,16,16,16,16,16,16,16,16,16,16,16,16,16,49,16,49,16,16,16,49,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,49,16,49,16,16,16,16,16,16,16,16,16,49,16,16,16,49,16,49,16,16,16,49,16,49,16,16,16,16,16,2703",
    ENTER: "1,37000,1,1,127,63,16,16,16,47,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,47,16,16,16,16,16,16,16,16,16,16,16,16,16,47,16,47,16,16,16,47,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,47,16,16,16,16,16,16,16,16,16,16,16,47,16,16,16,47,16,16,16,16,16,47,16,47,16,16,16,16,16,2741",
    LEFT: "1,37000,1,1,127,63,16,16,16,47,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,47,16,16,16,16,16,16,16,16,16,16,16,16,16,47,16,47,16,16,16,47,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,47,16,47,16,47,16,16,16,16,16,16,16,16,16,47,16,47,16,47,16,47,16,16,16,47,16,47,16,16,16,16,16,2741",
    RIGHT: "1,37000,1,1,127,63,16,16,16,47,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,47,16,16,16,16,16,16,16,16,16,16,16,16,16,47,16,47,16,16,16,47,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,47,16,16,16,16,16,16,16,47,16,16,16,16,16,16,16,47,16,47,16,47,16,16,16,16,16,2741",
    RETURN: "1,37000,1,1,128,62,15,15,15,47,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,47,15,15,15,15,15,15,15,15,15,15,15,15,15,47,15,47,15,15,15,47,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,47,15,15,15,15,15,15,15,15,15,15,15,15,15,47,15,47,15,15,15,15,15,15,15,47,15,47,15,15,15,15,15,2736",
    EJECT: "1,37000,1,1,127,65,16,16,16,49,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,49,16,16,16,16,16,16,16,16,16,16,16,16,16,49,16,49,16,16,16,49,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,49,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,49,16,16,16,16,16,16,16,49,16,49,16,17,16,49,16,2731"

  }
  var Power_command = {
    OFF: "1,37000,1,1,127,65,16,16,16,48,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,48,16,16,16,16,16,16,16,16,16,16,16,16,16,49,16,48,16,16,16,48,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,48,16,48,16,48,16,48,16,48,16,48,16,16,16,16,16,48,16,48,16,48,16,48,16,16,16,16,16,16,16,48,16,2731",
    ON: "1,37000,1,1,127,63,16,16,16,47,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,47,16,16,16,16,16,16,16,16,16,16,16,16,16,47,16,47,16,16,16,47,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,47,16,47,16,47,16,47,16,47,16,16,16,16,16,16,16,47,16,47,16,47,16,16,16,16,16,16,16,47,16,2741"
  }


  var Track_command = {
    FORWARD: "1,37000,1,1,127,63,16,16,16,47,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,47,16,16,16,16,16,16,16,16,16,16,16,16,16,47,16,47,16,16,16,47,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,47,16,16,16,47,16,16,16,16,16,16,16,16,16,16,16,47,16,16,16,47,16,16,16,47,16,47,16,16,16,47,16,2741",
    REVERSE: "1,37000,1,1,127,63,16,16,16,47,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,47,16,16,16,16,16,16,16,16,16,16,16,16,16,47,16,47,16,16,16,47,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,47,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,47,16,16,16,47,16,47,16,16,16,47,16,2741",
    STOP: "1,37000,1,1,127,63,16,16,16,47,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,47,16,16,16,16,16,16,16,16,16,16,16,16,16,47,16,47,16,16,16,47,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,47,16,47,16,16,16,47,16,2741",
    PLAY: "1,37000,1,1,127,63,16,16,16,47,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,47,16,16,16,16,16,16,16,16,16,16,16,16,16,47,16,47,16,16,16,47,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,47,16,16,16,47,16,16,16,16,16,16,16,16,16,16,16,47,16,16,16,47,16,47,16,47,16,16,16,47,16,2741",
    PREVIOUS: "1,37000,1,1,127,63,16,16,16,47,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,47,16,16,16,16,16,16,16,16,16,16,16,16,16,47,16,47,16,16,16,47,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,47,16,16,16,16,16,47,16,16,16,16,16,47,16,16,16,47,16,16,16,16,16,47,16,47,16,47,16,47,16,47,16,2741",
    NEXT: "1,37000,1,1,127,63,16,16,16,47,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,47,16,16,16,16,16,16,16,16,16,16,16,16,16,47,16,47,16,16,16,47,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,47,16,16,16,47,16,16,16,16,16,47,16,16,16,16,16,47,16,16,16,47,16,47,16,47,16,47,16,47,16,2741",
    PAUSE: "1,37000,1,1,127,63,16,16,16,47,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,47,16,16,16,16,16,16,16,16,16,16,16,16,16,47,16,47,16,16,16,47,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,47,16,47,16,16,16,16,16,16,16,16,16,16,16,16,16,47,16,47,16,16,16,47,16,47,16,16,16,47,16,2741"
  };

  const setPower = params => {
    base.getVar("Power").string = params.Status;
    switch (params.Status) {
      case "Off":
        sendDefer("sendir,"+  config.module + ":"+ config.ir_port +"," + Power_command.OFF + "\r")
        break;
      case "On":
        sendDefer("sendir,"+  config.module + ":"+ config.ir_port +"," + Power_command.ON + "\r")
        break;
      default:
        logger.silly("Wrong command variable sent to Set Power()")
        break;
    }

  }
  const selectSource = params => sendDefer(`!Source ${params.Name}\r`)
  const setAudioLevel = params => sendDefer(`!Level ${params.Level}\r`)

  const sendTrackCommand = params => {
    base.getVar("Track").string = params.Name;

    switch (params.Name) {
      case "Play":
        sendDefer("sendir,"+  config.module + ":"+ config.ir_port +"," + Track_command.PLAY + "\r")
        break;
      case "Pause":
        sendDefer("sendir,"+  config.module + ":"+ config.ir_port +"," + Track_command.PAUSE + "\r")
        break;
      case "Stop":
        sendDefer("sendir,"+  config.module + ":"+ config.ir_port +"," + Track_command.STOP + "\r")
        break;
      case "Forward":
        sendDefer("sendir,"+  config.module + ":"+ config.ir_port +"," + Track_command.FORWARD + "\r")
        break;
      case "Reverse":
        sendDefer("sendir,"+  config.module + ":"+ config.ir_port +"," + Track_command.REVERSE + "\r")
        break;
      case "Next":
        sendDefer("sendir,"+  config.module + ":"+ config.ir_port +"," + Track_command.NEXT + "\r")
        break;
      case "Previous":
        sendDefer("sendir,"+  config.module + ":"+ config.ir_port +"," + Track_command.PREVIOUS + "\r")
        break;
      default:
        logger.silly("Wrong command variable sent to function Send Track Command()")
        break;
    }
  }

  const sendCommand = params => {
    base.getVar("Commands").string = params.Name;

    switch (params.Name) {
      case "Up":
        sendDefer("sendir,"+  config.module + ":"+ config.ir_port +"," + Control_command.UP + "\r")
        break;
      case "Down":
        sendDefer("sendir,"+  config.module + ":"+ config.ir_port +"," + Control_command.DOWN + "\r")
        break;
      case "Left":
        sendDefer("sendir,"+  config.module + ":"+ config.ir_port +"," + Control_command.LEFT + "\r")
        break;
      case "Right":
        sendDefer("sendir,"+  config.module + ":"+ config.ir_port +"," + Control_command.RIGHT + "\r")
        break;
      case "Ok":
        sendDefer("sendir,"+  config.module + ":"+ config.ir_port +"," + Control_command.ENTER + "\r")
        break;
      case "Return":
        sendDefer("sendir,"+  config.module + ":"+ config.ir_port +"," + Control_command.RETURN + "\r")
        break;
      case "Eject":
        sendDefer("sendir,"+  config.module + ":"+ config.ir_port +"," + Control_command.EJECT + "\r")
        break;
      default:
        logger.silly("Wrong command variable sent to function Send Command()")
        break;
    }
  }




  const getPower = () => sendDefer("A")
  const getAudioLevel = () => sendDefer(`?Level\r`)

  const onFrame = data => {
    logger.silly(`onFrame ${data}`)
    base.commandDone()

  }

  const initTcpClient = () => {
    if (!tcpClient) {
      tcpClient = host.createTCPClient()

      tcpClient.on('connect', () => {
        logger.silly(`TCPClient connected`)
        base.getVar('Status').string = 'Connected'
      })

      tcpClient.on('data', data => {
        data = data.toString()
        logger.silly(`TCPClient data: ${data}`)
        onFrame(data)
      })

      tcpClient.on('close', () => {
        logger.silly(`TCPClient closed`)
        disconnect()
      })

      tcpClient.on('error', err => {
        logger.error(`TCPClient: ${err}`)
        disconnect()
      })
    }
  }

  const sendDefer = data => {
    if (send(data)) {
      base.commandDefer()
    } else {
      base.commandError(`Data not sent`)
    }
  }

  const send = data => {
    logger.silly(`TCPClient send: ${data}`)
    return tcpClient && tcpClient.write(data)
  }

  const disconnect = () => {
    //base.getVar('Status').string = 'Disconnected'
    //tcpClient && tcpClient.end()
  }

  return {
    setup, start, stop,
    setPower, selectSource, setAudioLevel, getPower, getAudioLevel, sendTrackCommand, sendCommand
  }
}