let host
exports.init = _host => {
  host = _host
}

exports.createDevice = base => {
  const logger = base.logger || host.logger
  let config
  let tcpClient

  let frameParser = host.createFrameParser()
  frameParser.setSeparator(/FB.{4}/)  // 1st byte is always 0xFB, followed by 4 bytes
  frameParser.on('data', data => onFrame(data))

  const setup = _config => {
    config = _config
    base.setPoll('Get Info', 10000)
  }

  const start = () => {
    initTcpClient()
    tcpClient.connect(config.port, config.host)
    base.startPolling()
  }

  const stop = () => {
    disconnect()
  }

  const getInfo = () => { sendDefer(Buffer.from([0xFA, config.address, 0x14, 0, 0])); }

  const setPower = params => {
    // sendDefer(Buffer.from())
  }

  const setPosition = params => {
    // 1, 1 = up. 1, 0 = down
    // sendDefer(Buffer.from())
  }

  const setButtonLock = params => {
    // sendDefer(Buffer.from())
  }

  const initTcpClient = () => {
    if (!tcpClient) {
      tcpClient = host.createTCPClient()

      tcpClient.on('connect', () => {
        logger.silly(`TCPClient connected`)
        base.getVar('Status').string = 'Connected'
      })

      tcpClient.on('data', data => {
        data = data.toString('hex').toUpperCase()
        logger.silly(`TCPClient data: ${data}`)
        frameParser.push(data)
      })

      tcpClient.on('close', () => {
        logger.silly(`TCPClient closed`)
        disconnect()
      })

      tcpClient.on('error', err => {
        logger.error(`TCPClient: ${err}`)
        disconnect()
      })
    }
  }

  const disconnect = () => {
    base.getVar('Status').string = 'Disconnected'
    tcpClient && tcpClient.end()
  }

  const send = data => {
    logger.silly(`TCPClient send: ${data}`)
    return tcpClient && tcpClient.write(data)
  }

  const sendDefer = data => {
    if (send(data)) base.commandDefer(1000)
    else base.commandError(`Data not sent`)
  }

  const onFrame = data => {
    base.commandDone()
    let match
    // match = data.match(/POWR(\d+)/)
    // match && (base.getVar('Power').string = (parseInt(match[1]) == 1) ? 'On' : 'Off')
    logger.debug(data)
  }

  function tick() {
    if (base.getVar('Status').string == 'Disconnected') {
      initTcpClient()
      tcpClient.connect(config.port, config.host)
    }
  }

  return {
    setup, start, stop, tick,
    setPower, setPosition, setButtonLock, getInfo
  }
}