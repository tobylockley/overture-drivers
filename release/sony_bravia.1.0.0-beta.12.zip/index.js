let host
exports.init = _host => {
  host = _host
}

exports.createDevice = base => {
  const logger = base.logger || host.logger
  let config
  let tcpClient
  let lastCommand = ''
  let muteFlag
  let channelFlag
  base.setTickPeriod(5000)

  const setup = _config => {
    logger.debug('Setup')
    config = _config
    base.setPoll('Get Power', 5000)
    base.setPoll('Get Source', 5000)
    base.setPoll('Get Audio Level', 2000)
    base.setPoll('Get Mute', 5000)
  }

  const start = () => {
    logger.debug('Starting')
    initTcpClient()
    tcpClient.connect(config.port, config.host)
    base.startPolling()
  }

  const stop = () => {
    logger.debug('Stoping')
  }

  const getPower = () => sendDefer(Buffer.from([0x2a, 0x53, 0x45, 0x50, 0x4f, 0x57, 0x52, 0x23, 0x23, 0x23, 0x23, 0x23, 0x23, 0x23, 0x23, 0x23, 0x23, 0x23, 0x23, 0x23, 0x23, 0x23, 0x23, 0x0a]))
  const getSource = () => sendDefer(Buffer.from([0x2a, 0x53, 0x45, 0x49, 0x4e, 0x50, 0x54, 0x23, 0x23, 0x23, 0x23, 0x23, 0x23, 0x23, 0x23, 0x23, 0x23, 0x23, 0x23, 0x23, 0x23, 0x23, 0x23, 0x0a]))
  const getAudioLevel = () => sendDefer(Buffer.from([0x2a, 0x53, 0x45, 0x56, 0x4f, 0x4c, 0x55, 0x23, 0x23, 0x23, 0x23, 0x23, 0x23, 0x23, 0x23, 0x23, 0x23, 0x23, 0x23, 0x23, 0x23, 0x23, 0x23, 0x0a]))
  const getMute = () => sendDefer("*SEAMUT################\n")
  
  const getChannel = () => {
    if (base.getVar('Sources').string == "DTV") {
      sendDefer("*SECHNN################\n")
    }
    else {
      logger.info("TV not in DTV mode, cannot change channel.")
    }
  }


  const setPower = params => {
    logger.debug(`Testing Power Function----------------------------------------------------------------`)
    if (params.Status == 'Off') {
      var power_buffer = Buffer.from([0x2a, 0x53, 0x43, 0x50, 0x4f, 0x57, 0x52, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x0a])
      sendDefer(power_buffer)
      lastCommand = 'Power Off'
    }
    else if (params.Status == 'On') {
      var power_buffer = Buffer.from([0x2a, 0x53, 0x43, 0x50, 0x4f, 0x57, 0x52, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x31, 0x0a])
      sendDefer(power_buffer)
      lastCommand = 'Power On'
    }

  }

  const setAudioMute = params => {
    muteFlag = 1
    if (params.Status == "Off") {
      sendDefer("*SCAMUT0000000000000000\n")
    }
    else if (params.Status == "On") {
      sendDefer("*SCAMUT0000000000000001\n")
    }
  }



  const setChannel = params => {
    channelFlag = 1
    if (params.Name < 10) {
      var channel = ("0" + params.Name.toString())
    }
    else if (params.Name >= 10) {
      var channel = params.Name.toString()
    }
    sendDefer("*SCCHNN000000" + channel + ".0000000\n")
  }


  const selectSource = params => {
    //logger.debug(`selectSource ${params.Name}`)
    if (params.Name == 'DTV') {
      sendDefer("*SCINPT0000000000000000\n")
      lastCommand = 'Source DTV'
    }
    else {
      var source_hex = parseInt(params.Name.replace(/\D/g , ''), 16) + 0x30
      var hdmi_buffer = Buffer.from([0x2a, 0x53, 0x43, 0x49, 0x4e, 0x50, 0x54, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x31, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30, source_hex, 0x0a])
      sendDefer(hdmi_buffer)
      lastCommand = 'Source HDMI' + parseInt(params.Name.replace(/\D/g , ''), 10)
    }

  }

  const setAudioLevel = params => {
    //logger.debug(`setAudioLevel ${params.Level}`)
    let ones
    let tens
    let hundreds
    if (params.Level == 0) {
      params.Level = 1
    }
    if (params.Level.toString().length == 3) {
      ones = params.Level.toString().substring(2)
      tens = params.Level.toString().substring(1, 2)
      hundreds = params.Level.toString().substring(0, 1)
    }
    else if (params.Level.toString().length == 2) {
      ones = params.Level.toString().substring(1)
      tens = params.Level.toString().substring(0, 1)
      hundreds = 0
    }
    else if (params.Level.toString().length == 1) {
      ones = params.Level
      tens = 0
      hundreds = 0
    }
    ones = parseInt(ones) + 48
    tens = parseInt(tens) + 48
    hundreds = parseInt(hundreds) + 48
    var audio_buffer = Buffer.from([0x2a, 0x53, 0x43, 0x56, 0x4f, 0x4c, 0x55, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30, hundreds, tens, ones, 0x0A])

    sendDefer(audio_buffer)
    lastCommand = 'Audio'

    //logger.silly(audio_buffer)
  }
  const initTcpClient = () => {
    if (!tcpClient) {
      tcpClient = host.createTCPClient()

      tcpClient.on('connect', () => {
        logger.silly(`TCPClient connected`)
        base.getVar('Status').string = 'Connected'
      })

      tcpClient.on('data', data => {
        data = data.toString()
        logger.silly(`TCPClient data: ${data}`)
        onFrame(data)
      })

      tcpClient.on('close', () => {
        logger.silly(`TCPClient closed`)
        disconnect()
      })

      tcpClient.on('error', err => {
        logger.error(`TCPClient: ${err}`)
        disconnect()
      })
    }
  }
  const disconnect = () => {
    base.getVar('Status').string = 'Disconnected'
    tcpClient && tcpClient.end()
  }

  const send = data => {
    logger.silly(`TCPClient send: ${data}`)
    return tcpClient && tcpClient.write(data)
  }
  const sendDefer = data => {
    if (send(data)) {
      base.commandDefer(1000)
    } else {
      base.commandError(`Data not sent`)
    }
  }
  const onFrame = data => {
    // logger.silly(`onFrame ${data}`)
    base.commandDone()
    if (data.search('POWR') > 0) {
      if (data.charAt(22) == '1') {
        base.getVar('Power').string = 'On'
      }
      else if (data.charAt(22) == '0') {
        base.getVar('Power').string = 'Off'
      }
    }
    else if (data.search('INPT00000001') > 0) {
      var inputValue = "HDMI" + data.charAt(22)
      base.getVar('Sources').string = inputValue
    }
    else if (data.search('INPT00000000') > 0) {
      //var inputValue = "HDMI" + data.charAt(22)
      base.getVar('Sources').string = "DTV"
    }

    

    else if (data.search('AMUT0000000000000000') > 0) {
      if (muteFlag) {
        muteFlag = 0
        base.perform('Get Mute')
      }
      else {
        base.getVar('Mute').string = "Unmute"
      }
    }

    else if (data.search('AMUT0000000000000001') > 0) {
      base.getVar('Mute').string = "Mute"
    }



    else if ((data.search('VOLU') > 0) && (data.search('VOLU0000000000000000') < 1)) {
      var audioValue = data.substring(20, 23)
      base.getVar('AudioLevel').value = audioValue
    }

  }

  function tick() {
    if (base.getVar('Status').string == 'Disconnected') {
      initTcpClient()
      tcpClient.connect(config.port, config.host)
    }
  }



  return {
    setup, start, stop,
    setPower, selectSource, setAudioLevel, getPower, getSource, getAudioLevel, getMute, setAudioMute, tick, setChannel
  }
}