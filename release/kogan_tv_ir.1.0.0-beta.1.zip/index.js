let host
exports.init = _host => {
  host = _host
}

exports.createDevice = base => {
  const logger = base.logger || host.logger
  let config
  let tcpClient

  const setup = _config => {
    config = _config
    base.setPoll('Keep Alive', 10000)
  }

  const start = () => {
    initTcpClient()
    tcpClient.connect(config.port, config.host)
    base.startPolling()
  }

  const stop = () => {
    disconnect()
  }

  var Command = {
    UP: "sendir,1:1,1,38000,1,69,342,171,21,21,21,21,21,21,21,21,21,21,21,21,21,64,21,21,21,64,21,64,21,64,21,64,21,64,21,64,21,21,21,64,21,64,21,64,21,21,21,64,21,21,21,64,21,21,21,21,21,21,21,21,21,64,21,21,21,64,21,21,21,64,21,64,21,1534,342,85,21,3662",
    DOWN: "sendir,1:1,1,38000,1,69,342,171,21,21,21,21,21,21,21,21,21,21,21,21,21,64,21,21,21,64,21,64,21,64,21,64,21,64,21,64,21,21,21,64,21,21,21,21,21,64,21,64,21,21,21,64,21,21,21,21,21,64,21,64,21,21,21,21,21,64,21,21,21,64,21,64,21,1533,342,85,21,3662",
    LEFT: "sendir,1:1,1,38000,1,69,342,171,21,21,21,21,21,21,21,21,21,21,21,21,21,63,21,21,21,63,21,63,21,63,21,63,21,63,21,63,21,21,21,63,21,63,21,21,21,63,21,63,21,21,21,63,21,21,21,21,21,21,21,63,21,21,21,21,21,63,21,21,21,63,21,63,21,1533,342,85,21,3662",
    RIGHT: "sendir,1:1,1,38000,1,69,342,171,21,21,21,21,21,21,21,21,21,21,21,21,21,64,21,21,21,64,21,64,21,64,21,64,21,64,21,64,21,21,21,64,21,21,21,64,21,64,21,64,21,21,21,64,21,21,21,21,21,64,21,21,21,21,21,21,21,64,21,21,21,64,21,64,21,1534,342,85,21,3662",
    MENU: "sendir,1:1,1,38000,1,69,342,171,21,21,21,21,21,21,21,21,21,21,21,21,21,63,21,21,21,63,21,63,21,63,21,63,21,63,21,63,21,21,21,63,21,63,21,21,21,63,21,21,21,63,21,21,21,21,21,21,21,21,21,63,21,21,21,63,21,21,21,63,21,63,21,63,21,1533,342,85,21,3662",
    ENTER: "sendir,1:1,1,38000,1,69,342,171,21,21,21,21,21,21,21,21,21,21,21,21,21,64,21,21,21,64,21,64,21,64,21,64,21,64,21,64,21,21,21,64,21,64,21,64,21,64,21,64,21,21,21,64,21,21,21,21,21,21,21,21,21,21,21,21,21,64,21,21,21,64,21,64,21,1533,342,85,21,3662",
    EXIT: "sendir,1:1,1,38000,1,69,342,171,21,21,21,21,21,21,21,21,21,21,21,21,21,64,21,21,21,64,21,64,21,64,21,64,21,64,21,64,21,21,21,64,21,21,21,21,21,21,21,21,21,64,21,64,21,21,21,21,21,64,21,64,21,64,21,64,21,21,21,21,21,64,21,64,21,1534,342,85,21,3662",
    SOURCE: "sendir,1:1,1,38000,1,69,342,171,21,21,21,21,21,21,21,21,21,21,21,21,21,64,21,21,21,64,21,64,21,64,21,64,21,64,21,64,21,21,21,64,21,64,21,64,21,64,21,64,21,21,21,21,21,21,21,21,21,21,21,21,21,21,21,21,21,64,21,64,21,64,21,64,21,1534,342,85,21,3662",
    POWER: "sendir,1:1,1,38000,1,69,342,171,21,21,21,21,21,21,21,21,21,21,21,21,21,63,21,21,21,63,21,63,21,63,21,63,21,63,21,63,21,21,21,63,21,63,21,63,21,21,21,63,21,21,21,21,21,21,21,21,21,21,21,21,21,63,21,21,21,63,21,63,21,63,21,63,21,1533,342,85,21,3662"
  }

  var Volume = {
    UP: "sendir,1:1,1,38000,1,69,342,171,21,21,21,21,21,21,21,21,21,21,21,21,21,63,21,21,21,63,21,63,21,63,21,63,21,63,21,63,21,21,21,63,21,63,21,63,21,21,21,21,21,63,21,21,21,21,21,21,21,21,21,21,21,63,21,63,21,21,21,63,21,63,21,63,21,1533,342,85,21,3662",
    DOWN: "sendir,1:1,1,38000,1,69,342,171,21,21,21,21,21,21,21,21,21,21,21,21,21,63,21,21,21,63,21,63,21,63,21,63,21,63,21,63,21,21,21,63,21,21,21,63,21,21,21,21,21,63,21,21,21,21,21,21,21,63,21,21,21,63,21,63,21,21,21,63,21,63,21,63,21,1533,342,85,21,3662",
    MUTE: "sendir,1:1,1,38000,1,69,342,171,21,21,21,21,21,21,21,21,21,21,21,21,21,64,21,21,21,64,21,64,21,64,21,64,21,64,21,64,21,21,21,64,21,21,21,21,21,64,21,21,21,64,21,21,21,21,21,21,21,64,21,64,21,21,21,64,21,21,21,64,21,64,21,64,21,1533,342,85,21,3662"
  }

  var Channel = {
    UP: "sendir,1:1,1,38000,1,69,342,171,21,21,21,21,21,21,21,21,21,21,21,21,21,64,21,21,21,64,21,64,21,64,21,64,21,64,21,64,21,21,21,64,21,64,21,21,21,21,21,21,21,64,21,21,21,21,21,21,21,21,21,64,21,64,21,64,21,21,21,64,21,64,21,64,21,1533,342,85,21,3662",
    DOWN: "sendir,1:1,1,38000,1,69,342,171,21,21,21,21,21,21,21,21,21,21,21,21,21,64,21,21,21,64,21,64,21,64,21,64,21,64,21,64,21,21,21,64,21,21,21,21,21,21,21,21,21,64,21,21,21,21,21,21,21,64,21,64,21,64,21,64,21,21,21,64,21,64,21,64,21,1534,342,85,21,3662"
  }

  const keepAlive = () => sendDefer("A")

  const sendCommand = params => {
    base.getVar("Commands").string = params.Name;
    switch (params.Name) {
      case "Up":
        sendDefer("sendir,"+  config.module + ":"+ config.ir_port +"," + Command.UP + "\r")
        break;
      case "Down":
        sendDefer("sendir,"+  config.module + ":"+ config.ir_port +"," + Command.DOWN + "\r")
        break;
      case "Left":
        sendDefer("sendir,"+  config.module + ":"+ config.ir_port +"," + Command.LEFT + "\r")
        break;
      case "Right":
        sendDefer("sendir,"+  config.module + ":"+ config.ir_port +"," + Command.RIGHT + "\r")
        break;
      case "Menu":
        sendDefer("sendir,"+  config.module + ":"+ config.ir_port +"," + Command.MENU + "\r")
        break;
      case "Enter":
        sendDefer("sendir,"+  config.module + ":"+ config.ir_port +"," + Command.ENTER + "\r")
        break;
      case "Exit":
        sendDefer("sendir,"+  config.module + ":"+ config.ir_port +"," + Command.EXIT + "\r")
        break;
      case "Source":
        sendDefer("sendir,"+  config.module + ":"+ config.ir_port +"," + Command.SOURCE + "\r")
        break;
      case "Power":
        sendDefer("sendir,"+  config.module + ":"+ config.ir_port +"," + Command.POWER + "\r")
        break;
    }
  }

  const sendVolume = params => {
    base.getVar("Volume").string = params.Name;
    switch (params.Name) {
      case "Up":
        sendDefer("sendir,"+  config.module + ":"+ config.ir_port +"," + Volume.UP + "\r")
        break;
      case "Down":
        sendDefer("sendir,"+  config.module + ":"+ config.ir_port +"," + Volume.DOWN + "\r")
        break;
      case "Mute":
        sendDefer("sendir,"+  config.module + ":"+ config.ir_port +"," + Volume.MUTE + "\r")
        break;
    }
  }

  const sendChannel = params => {
    base.getVar("Channel").string = params.Name;
    switch (params.Name) {
      case "Up":
        sendDefer("sendir,"+  config.module + ":"+ config.ir_port +"," + Channel.UP + "\r")
        break;
      case "Down":
        sendDefer("sendir,"+  config.module + ":"+ config.ir_port +"," + Channel.DOWN + "\r")
        break;
    }
  }

  const onFrame = data => {
    logger.silly(`onFrame ${data}`)
    base.commandDone()
  }

  function tick() {
    if (base.getVar('Status').string == 'Disconnected'){
      initTcpClient()
      tcpClient.connect(config.port, config.host)
    }
  }

  const initTcpClient = () => {
    if (!tcpClient) {
      tcpClient = host.createTCPClient()

      tcpClient.on('connect', () => {
        logger.silly(`TCPClient connected`)
        base.getVar('Status').string = 'Connected'
      })

      tcpClient.on('data', data => {
        data = data.toString()
        logger.silly(`TCPClient data: ${data}`)
        onFrame(data)
      })

      tcpClient.on('close', () => {
        logger.silly(`TCPClient closed`)
        disconnect()
      })

      tcpClient.on('error', err => {
        logger.error(`TCPClient: ${err}`)
        disconnect()
      })
    }
  }

  const sendDefer = data => {
    if (send(data)) {
      base.commandDefer()
    } else {
      base.commandError(`Data not sent`)
    }
  }

  const send = data => {
    logger.silly(`TCPClient send: ${data}`)
    return tcpClient && tcpClient.write(data)
  }

  const disconnect = () => {
    //base.getVar('Status').string = 'Disconnected'
    //tcpClient && tcpClient.end()
  }

  return {
    setup, start, stop, tick, keepAlive,
    sendCommand, sendVolume, sendChannel
  }
}